# ZKTeco Biometric Attendance Gateway (`zkbio`)

A small, self-contained appliance that runs on a **Raspberry Pi 4** on the same
LAN as your ZKTeco biometric devices. It collects attendance punches from those
devices, stores every punch durably with a delivery status, and forwards them to
the ERP **HR service** (`ismila/erp/hrm`) — the same cluster this repo lives in
under `devices/`.

It is the bridge between the ZKTeco devices and the HR module's biometric
ingestion endpoint (`POST /device/attendance/logs`), and it is built to be
unattended: it starts with the Pi, and after any restart it knows exactly which
punches have already been delivered and which have not, so nothing is lost and
nothing is sent twice.

Stack: **Go (Gin) + MariaDB + phpMyAdmin**, all in Docker Compose.

---

## What it does

- **Collects punches two ways**, so it works with most ZKTeco devices — the way
  open-source tools (pyzk, node-zklib) and BioTime do:
  - **Pull** — the gateway connects out to each device over TCP **4370** on a
    timer and reads new attendance logs (the classic ZK protocol).
  - **Push** — devices configured with the gateway as their **ADMS / "cloud"
    server** connect in and stream punches in real time over HTTP
    (`/iclock/cdata`).
- **Stores every punch first**, in local MariaDB, with a delivery status
  (`Pending` → `Sent` / `Failed`). A unique key makes both collection and
  re-delivery idempotent.
- **Forwards to HR** in batches, each under that device's own HR credential
  (`X-Device-Id` / `X-Device-Key`), retrying on failure with the database as the
  queue.
- **Survives reboots** — on boot it resumes delivering whatever is still
  `Pending`. A punch becomes `Sent` only after HR confirms receipt.
- **Exposes phpMyAdmin on the LAN** so staff can view the data in a browser.

---

## Architecture

```
   ZKTeco devices                         Raspberry Pi (this appliance)                 Cloud
 ┌───────────────┐   pull  TCP 4370   ┌───────────────────────────────────┐
 │  Device A     │◀───────────────────│  zkbio (Go/Gin)                    │
 │  Device B     │                    │   ├─ collector  (pull poller)      │   HTTPS   ┌──────────────┐
 │  ...          │───────────────────▶│   ├─ iclock     (push endpoints)   │──────────▶│  ERP HR svc  │
 └───────────────┘   push  HTTP /iclock│   ├─ forwarder  (delivery)         │  X-Device │  /device/    │
                                       │   └─ management API + dashboard    │  headers  │  attendance/ │
                                       │           │                        │           │  logs        │
                                       │        MariaDB (durable queue)     │           └──────────────┘
                                       │        phpMyAdmin  :8081 (LAN)     │
                                       └───────────────────────────────────┘
```

The code follows the same four-layer layout as the other ERP Go services
(`routes → controllers → database/*_db → database/gendb`); see `CLAUDE.md`.

### The HR ingest contract (must stay in lock-step)

The gateway delivers to HR exactly what HR expects:

```
POST {HR_INGEST_URL}
Headers: X-Device-Id, X-Device-Key         (per-device credential; company derived from it)
Body:    { "logs": [ { "employeeNumber": "...", "logType": "IN|OUT",
                       "eventTime": "RFC3339", "latitude": null, "longitude": null } ] }
Reply:   AnswerResponse{ data: { total, accepted, ignored, failed, duplicate } }
```

HR stores each raw punch **before** processing it, so an HTTP 200 means "durably
received" — the gateway then marks those punches `Sent`. HR de-duplicates on
`(device, employeeNumber, logType, eventTime)`, so a retried batch is a no-op on
both sides.

---

## Quick start (on the Pi)

```bash
git clone <this repo>          # into e.g. /opt/zkteco_bio_server
cd zkteco_bio_server

make init                      # copies .env and env/*.env from the examples
# edit .env, env/zkbio.env, env/db.env, env/phpmyadmin.env — replace every CHANGEME
#   - set HR_INGEST_URL to https://<your-erp-domain>/hrm/device/attendance/logs
#   - generate CRED_ENC_KEY:  openssl rand -base64 32
#   - generate MGMT_API_KEY:  openssl rand -hex 24
#   - make MYSQL_PASS == ERP_ZKBIO_DB_PASSWORD

make up                        # preflight + build + start (detached)
```

Then, to survive power cuts, install the systemd unit (see `systemd/README.md`).

Endpoints once running:
- Gateway API + device push: `http://<pi-ip>:8080`
- phpMyAdmin: `http://<pi-ip>:8081` (log in as `erp_ro` for read-only viewing)

The gateway creates and migrates its own database tables on startup, so there is
no separate migration step.

---

## Registering a device

Each physical ZKTeco unit maps to its **own HR device credential**, so HR can
tell which unit a punch came from.

1. **On the HR service**, an admin creates the credential:
   `POST /hrm/devices  { "name": "Main Gate", "location": "..." }` →
   returns `deviceIdentifier` (X-Device-Id) and a one-time `apiKey` (X-Device-Key).

2. **On the gateway**, register the unit and attach that credential:

   ```bash
   curl -X POST http://<pi-ip>:8080/devices \
     -H "X-API-Key: $MGMT_API_KEY" -H "Content-Type: application/json" \
     -d '{
           "name": "Main Gate",
           "mode": "both",
           "ipAddress": "192.168.1.201",
           "serialNumber": "CJXK201960000",
           "port": 4370,
           "hrDeviceId": "dev_1a2b3c4d5e6f7a8b",
           "hrDeviceKey": "the-one-time-apiKey-from-HR"
         }'
   ```

   or run `make register-device` for an interactive prompt.

### Configuring the devices themselves

- **Pull mode** — nothing needed on the device beyond a static IP the gateway can
  reach on port 4370. If the device has a COMM/communication password, pass it as
  `commPassword`.
- **Push mode** — in the device's network / cloud (ADMS) settings, set the server
  address to the Pi's IP and port **8080** (path `/iclock`). The device will
  register and start pushing. If `PUSH_AUTO_REGISTER_SN=true`, an unknown device
  that starts pushing is auto-added (inactive of credential) so you only need to
  attach its HR credential afterward via
  `POST /devices/{id}/hr-credential`.

### Punch direction (IN/OUT)

HR needs `IN`/`OUT`. Devices report a numeric punch **state**; the gateway maps
it (0→IN, 1→OUT, plus break/overtime pairs). If a device is not configured for
direction and reports only state 0, everything maps to `IN` and HR's shift logic
pairs punches by time. To force a mapping, set a device `punchStateMap`, e.g.
`{"0":"IN","1":"OUT"}`.

---

## Management API

All JSON endpoints require the header `X-API-Key: <MGMT_API_KEY>` (or
`Authorization: Bearer <MGMT_API_KEY>`). The device-facing `/iclock/*` endpoints
are unauthenticated by design (LAN-local, device-driven).

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | liveness |
| GET | `/dashboard` | counts (pending/failed/sent) + per-device health |
| GET | `/devices` | list devices (paginated) |
| POST | `/devices` | register a device |
| GET | `/devices/:id` | get one device |
| PATCH | `/devices/:id` | update a device |
| DELETE | `/devices/:id` | delete a device (punch history retained) |
| POST | `/devices/:id/hr-credential` | set / rotate the HR credential |
| POST | `/devices/:id/requeue` | requeue this device's `Failed` punches |
| GET | `/punches` | list stored punches + delivery status (filter: `deviceId`, `employeeNumber`, `status`, `from`, `to`) |

---

## How "nothing is lost, nothing is sent twice" works

- Every punch is written to `attendance_punches` **before** any delivery attempt,
  as `Pending`.
- A unique key `(device_id, employee_number, log_type, event_time)` means the same
  physical punch — re-read on the next poll, or re-pushed — collapses to one row.
- The forwarder marks a punch `Sent` only after HR returns HTTP 200 for its batch.
  A crash between "HR received it" and "we recorded Sent" just means the batch is
  re-sent and HR de-duplicates it.
- On boot there is no in-memory state to rebuild: the forwarder queries what is
  still `Pending` and drains it.
- Delivered punches are purged after `PUNCH_RETENTION_SECONDS`; `Pending` and
  `Failed` punches are **never** purged.

---

## Troubleshooting

- **A device shows `hrCredentialSet: false` on the dashboard** — its punches are
  being stored but held `Pending`. Attach a credential with
  `POST /devices/:id/hr-credential`.
- **`Failed` punches** — usually HR rejected the device credential (rotate it and
  `POST /devices/:id/requeue`) or an employee number is unknown to HR. Check the
  punch's `lastError` and the `delivery_batches` table.
- **Pull not working on a particular model** — a minority of firmwares only speak
  the newer buffered transfer; switch that device to push (ADMS) mode. Pull
  results should be spot-checked per model on first deployment.
- **View raw data** — phpMyAdmin at `:8081`, tables `zk_devices`,
  `attendance_punches`, `delivery_batches`.

## Repo layout

```
Dockerfile              arm64 multi-stage build for the Pi
docker-compose.yml      zkbio + mariadb + phpmyadmin
.env.example            compose-level config (ports, TZ)
env/*.env.example       per-service runtime config
db/init/                first-start DB + user creation
migrations/001_init.sql canonical schema (the app also applies it on boot)
systemd/                boot-persistence unit
scripts/                preflight + register-device helpers
src/                    the Go module (ismila/erp/zkbio) — see CLAUDE.md
```
