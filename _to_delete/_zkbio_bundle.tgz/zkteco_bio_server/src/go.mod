module ismila/erp/zkbio

go 1.24

require (
	github.com/gin-contrib/cors v1.7.7
	github.com/gin-gonic/gin v1.12.0
	github.com/go-sql-driver/mysql v1.10.0
	github.com/joho/godotenv v1.5.1
	gopkg.in/natefinch/lumberjack.v2 v2.2.1
)
